#include <iostream>
#include "md5.h"
#include "Blowfish.h"
#include <ctime>
using namespace std;


class encryp_decrypt{
private:
    char key[1000]="$���d�]�`H|:y�B�D�\u001C�;��\u000F�S��\u0005\u0016��!l��m�E(��m%L\u0001�@�k\u000E\u001B�;rT���2�u*\t\u0018ŏTN�p�ŋ�[\u0002@ŨZ�\u001A�\u0014��p\u0004x��Q��\u0017(\u0016�s�02���\u0014�1�;ZiT-";
    vector<char> phase,keys, values;
    char mainstring[10000];

public:
    void encryptfunction(char *value) {
        char keysdata[1000];
        if (value == NULL) {
            exit(1);
        }
        int i;
        keys = chartovector(key);
        Blowfish b(keys);
        phase = chartovector(value);
        values = b.Encrypt(phase);
        vector<char> newdata;
        vectortochar(keysdata,values);
        display(values);
        cout<<keysdata;
        cout<<endl<<md5(keysdata);
        cout<<"end";
    }
    void decryptfucntion() {

    }


    vector<char> chartovector(char *chararray)
    {
        vector<char> v;
        if(chararray == NULL)
        {
            exit(0);
        }
        for(int i = 0; chararray[i]!='\0';i++)
        {
            v.push_back(chararray[i]);
        }

        return v;
    }


    void vectortochar(char *chararray, vector<char> &v) {
        for (int i = 0; i < v.size(); i++) {
            chararray[i] = v[i];
        }

    }


    void display(vector<char> &v)
    {
        for(int i = 0; i < v.size(); i++)
        {
            cout << v[i];
        }
        cout << "\n" << endl;
    }
};

int main() {
    char a[] = "hello world";
    encryp_decrypt e;
    e.encryptfunction(a);

    return 0;
}


//    key s;
//    char data[100];
//
//    cout << "Hello, World!" << endl;
//    gen_random(s.a,200);
//    cout << s.a << endl;
//    cin >>data;
//    cout << md5("abc") << endl;
//    vector <char> v,block, displaydata;
//    for(int i=0;s.a[i]!='\0';i++){
//        v.push_back(s.a[i]);
//    }
//    Blowfish b(v);
//    for(int i=0;data[i]!='\0';i++){
//        block.push_back(data[i]);
//    }
//    displaydata = b.Encrypt(block);
//    display(displaydata);
//    displaydata = b.Decrypt(displaydata);
//    display(displaydata);
